import React from 'react'

const card = (item) => {
  return (
    <div>
      this is card
    </div>
  )
}

export default card
