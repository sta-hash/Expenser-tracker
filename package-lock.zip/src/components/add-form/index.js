import React from 'react'
import './add-form.css';
const AddForm = () => {
  return (
    <div className="add-form">
<div className="form-item">
    <label>title</label>
    <input placeholder ="give a name to your expenditure" value='' onChange={()=>console.log["hello"]}></input>

</div>
    <div className="form-item">Amount</div> 
    <div className="category-container-parent"></div>
    </div>
  )
}

export default AddForm;
