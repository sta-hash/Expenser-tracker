// import logo from './logo.svg';
// import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Header from "./components/header";
import AddExpense from './page/add-expense';
import Home from './page/home';


const  App = ()=> {
  
  return (
    <BrowserRouter>
    <Header/>
      <Routes>
        <Route path="/" element={<Home />}>
          <Route path="add-expense" element={<AddExpense />} />
        </Route>
      </Routes>
      <div>footer</div>
    </BrowserRouter>
  );
  }
export default App
